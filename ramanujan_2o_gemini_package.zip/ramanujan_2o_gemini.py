"""RAMANUJAN 2.O — refined Streamlit chatbot prototype.

Run locally:
    pip install -r requirements_ramanujan.txt
    streamlit run ramanujan_2o_refined.py

For model-powered answers, create a Gemini API key and add GEMINI_API_KEY
in Streamlit Community Cloud > App settings > Secrets. Without a key, the app
uses a small rule-based fallback and clearly indicates that mode.
"""

from __future__ import annotations

import html
import os
import random
import time
from datetime import datetime
from typing import Optional

import streamlit as st

st.set_page_config(
    page_title="RAMANUJAN 2.O",
    page_icon="🧠",
    layout="centered",
    initial_sidebar_state="collapsed",
)

st.markdown(
    """
    <style>
    .stApp { background: #050B14; color: #E2E8F0; }
    [data-testid="stHeader"] { background: rgba(5,11,20,0); }
    .company-title { color:#38BDF8; font-weight:800; font-size:.8rem;
        letter-spacing:.18em; margin-bottom:0; }
    .app-title { color:#fff; font-size:2.25rem; font-weight:750;
        margin-top:0; margin-bottom:.3rem; }
    .subtle { color:#94A3B8; }
    div[data-testid="stChatMessage"] { background:#0A192F;
        border:1px solid #172A45; border-radius:12px; }
    .stTextInput input, .stTextArea textarea { background:#0B1528!important;
        color:#fff!important; border:1px solid #1E293B!important; }
    .stButton button, .stFormSubmitButton button { border-radius:9px; }
    </style>
    """,
    unsafe_allow_html=True,
)

# ---------- Session state ----------
DEFAULTS = {
    "step": "name_entry",
    "user_name": "",
    "chat_history": [],
    "question_count": 0,
    "learned_memory": {},
    "evaluating": False,
    "pending_question": "",
    "option_a": "",
    "option_b": "",
}
for key, value in DEFAULTS.items():
    if key not in st.session_state:
        st.session_state[key] = value.copy() if isinstance(value, (dict, list)) else value

# ---------- Response engine ----------
def fallback_response(query: str, memory: dict[str, str]) -> str:
    """Transparent offline fallback; this is not a trained language model."""
    q = query.strip().lower()
    memory_note = ""
    # Prefer the most recent relevant saved note, using whole-word-ish substring matching.
    for key, value in reversed(list(memory.items())):
        if key and key in q:
            memory_note = f"\n\nFrom our saved chat note about **{key}**: {value}"
            break

    if any(word in q for word in ("hello", "hi", "hey", "namaste")):
        answer = f"Hello {st.session_state.user_name}! What would you like to work on today?"
    elif any(word in q for word in ("news", "latest", "today")):
        answer = (
            f"Today is {datetime.now().strftime('%B %d, %Y')}. I do not have live news access "
            "in offline mode, so I cannot verify current headlines. Connect a live information "
            "source or enable the language-model mode for broader assistance."
        )
    elif any(word in q for word in ("profit", "business", "company")):
        answer = (
            "A useful starting point is to define the customer, quantify the problem, estimate "
            "unit economics, and test demand before scaling. If you share the industry, costs, "
            "price, and expected sales, I can help structure a more specific analysis."
        )
    elif any(word in q for word in ("who are you", "your name", "ramanujan")):
        answer = (
            "I am RAMANUJAN 2.O, a chatbot prototype. In offline mode I use a small set of "
            "rules and saved conversation notes; I am not independently reasoning with a trained model."
        )
    else:
        answer = (
            "I can help you think this through, but my offline response engine is limited. "
            "Please add context, your goal, and any constraints so I can give a more useful response."
        )
    return answer + memory_note


def read_secret(name: str, default: str = "") -> str:
    """Read a secret from Streamlit secrets first, then environment variables."""
    try:
        value = st.secrets.get(name, "")
    except Exception:
        value = ""
    return str(value or os.getenv(name, default)).strip()


def model_response(query: str, variant: str = "primary") -> str:
    """Use Google's Gemini API when configured; otherwise use the offline fallback."""
    api_key = read_secret("GEMINI_API_KEY")
    if not api_key:
        return fallback_response(query, st.session_state.learned_memory)

    try:
        from google import genai
        from google.genai import types

        model_name = read_secret("GEMINI_MODEL", "gemini-3.8-flash")
        system_prompt = (
            "You are RAMANUJAN 2.O, a capable, respectful, clear, and honest AI assistant. "
            "Answer the actual question directly. Explain reasoning and uncertainty when useful. "
            "Do not invent facts, claim to have checked live information unless a tool actually did so, "
            "or simply flatter the user. For engineering and science, be rigorous and point out "
            "important limitations and safety issues."
        )
        if variant == "secondary":
            system_prompt += " Give a genuinely different but equally useful approach to the question."

        # Gemini uses the role name 'model' for assistant turns.
        history = []
        for item in st.session_state.chat_history[-12:]:
            role = "user" if item.get("role") == "user" else "model"
            text = str(item.get("text", "")).strip()
            if text:
                history.append(
                    types.Content(role=role, parts=[types.Part.from_text(text=text)])
                )

        client = genai.Client(api_key=api_key)
        chat = client.chats.create(
            model=model_name,
            history=history,
            config=types.GenerateContentConfig(
                system_instruction=system_prompt,
                temperature=0.7 if variant == "primary" else 0.9,
                max_output_tokens=2048,
            ),
        )
        response = chat.send_message(query)
        answer = (response.text or "").strip()
        if answer:
            st.session_state.pop("last_model_error", None)
            return answer
        raise RuntimeError("Gemini returned an empty response.")
    except Exception as exc:
        st.session_state.last_model_error = f"{type(exc).__name__}: {exc}"
        return (
            "I couldn't reach the AI model just now, so I have not generated an AI answer. "
            "Please check the Gemini API key, model name, quota, and app logs. "
            "The limited offline response engine is available only as a fallback. "
            "Open the sidebar for the technical error."
        )

def save_exchange(question: str, answer: str) -> None:
    st.session_state.chat_history.append({"role": "user", "text": question})
    st.session_state.chat_history.append({"role": "assistant", "text": answer})
    # Store the actual question and answer, rather than arbitrary final words.
    st.session_state.learned_memory[question.strip().lower()] = answer[:240]
    # Avoid unbounded session growth.
    st.session_state.chat_history = st.session_state.chat_history[-100:]
    st.session_state.learned_memory = dict(list(st.session_state.learned_memory.items())[-50:])

# ---------- Header ----------
st.markdown('<p class="company-title">VIDRENCE</p>', unsafe_allow_html=True)
st.markdown('<h1 class="app-title">RAMANUJAN 2.O</h1>', unsafe_allow_html=True)
api_enabled = bool(read_secret("GEMINI_API_KEY"))
if api_enabled:
    st.caption("Gemini AI mode configured · Responses may still need verification")
else:
    st.caption("Offline prototype mode · Add GEMINI_API_KEY in Streamlit App settings → Secrets")

# ---------- Name entry ----------
if st.session_state.step == "name_entry":
    st.write("### Welcome to the Inner Circle Engine")
    with st.form("identity_form"):
        name_input = st.text_input("What should I call you?", max_chars=60)
        start = st.form_submit_button("Initialize Chatbot", use_container_width=True)
    if start:
        clean_name = name_input.strip()
        if clean_name:
            st.session_state.user_name = clean_name
            st.session_state.step = "active_chat"
            st.rerun()
        else:
            st.error("Please enter a name before continuing.")
else:
    left, right = st.columns([1, 10])
    with left:
        st.markdown("<div style='font-size:2rem'>◉</div>", unsafe_allow_html=True)
    with right:
        st.markdown(f"<p class='subtle'>Ask your questions, {html.escape(st.session_state.user_name)}.</p>", unsafe_allow_html=True)

    for item in st.session_state.chat_history:
        role = "user" if item["role"] == "user" else "assistant"
        with st.chat_message(role, avatar="👤" if role == "user" else "🧠"):
            st.markdown(item["text"])

    if st.session_state.evaluating:
        st.warning("Feedback checkpoint: choose the response you prefer to continue.")
        st.markdown("**Your question**")
        st.write(st.session_state.pending_question)
        with st.expander("Response Model Alpha", expanded=True):
            st.markdown(st.session_state.option_a)
        with st.expander("Response Model Beta", expanded=True):
            st.markdown(st.session_state.option_b)
        with st.form("feedback_form"):
            choice = st.radio(
                "Which response is more useful?",
                ["Select a response", "Response Model Alpha", "Response Model Beta"],
                index=0,
            )
            submit_feedback = st.form_submit_button("Submit Feedback", use_container_width=True)
        if submit_feedback:
            if choice == "Select a response":
                st.error("Choose Alpha or Beta to continue.")
            else:
                answer = st.session_state.option_a if choice.endswith("Alpha") else st.session_state.option_b
                save_exchange(st.session_state.pending_question, answer)
                st.session_state.evaluating = False
                st.session_state.pending_question = ""
                st.session_state.option_a = ""
                st.session_state.option_b = ""
                st.rerun()
    else:
        with st.form("chat_input_form", clear_on_submit=True):
            user_input = st.text_input("Message", placeholder="Ask RAMANUJAN 2.O…", max_chars=4000)
            submitted = st.form_submit_button("Send", use_container_width=True)
        if submitted:
            question = user_input.strip()
            if question:
                st.session_state.question_count += 1
                if st.session_state.question_count % 10 == 0:
                    with st.spinner("Generating two responses…"):
                        st.session_state.option_a = model_response(question, "primary")
                        st.session_state.option_b = model_response(question, "secondary")
                    st.session_state.pending_question = question
                    st.session_state.evaluating = True
                    st.rerun()
                else:
                    with st.spinner("Thinking…"):
                        answer = model_response(question, "primary")
                    save_exchange(question, answer)
                    st.rerun()

    with st.sidebar:
        st.subheader("Session controls")
        st.caption(f"Questions asked: {st.session_state.question_count}")
        if st.button("Clear chat and restart", use_container_width=True):
            for key, value in DEFAULTS.items():
                st.session_state[key] = value.copy() if isinstance(value, (dict, list)) else value
            st.rerun()
        if st.button("Show saved notes", use_container_width=True):
            st.json(st.session_state.learned_memory)
        if "last_model_error" in st.session_state:
            st.warning("The model request failed; offline fallback was used.")
            st.caption(st.session_state.last_model_error[:500])
